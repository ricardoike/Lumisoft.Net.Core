﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.IMAP
{
    /// <summary>
    /// This class is base class for IMAP server untagged responses.
    /// </summary>
    public abstract class IMAP_r_u : IMAP_r
    {
    }
}
