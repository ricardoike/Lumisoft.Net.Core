﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LumiSoft.Net.ABNF
{    
    /// <summary>
    /// This class represent ABNF "hex-val". Defined in RFC 5234 4.
    /// </summary>
    public class ABNF_HexVal
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public ABNF_HexVal()
        {
        }


        #region Properties implementation

        #endregion
    }
}
