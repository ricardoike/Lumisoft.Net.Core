

Filter description.

Filter runs virus scan soft and returns scanned message to server.

 




