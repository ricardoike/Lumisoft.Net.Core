
You can download free version(Community Edition) of Visual Studio 2013 from:
http://www.visualstudio.com/downloads/download-visual-studio-vs